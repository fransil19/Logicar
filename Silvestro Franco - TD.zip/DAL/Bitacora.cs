﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    public class Bitacora
    {
        Acceso _acceso;

        public Bitacora()
        {
            _acceso = new Acceso();
        }

        public void RegistrarBitacora(BE.Bitacora bitacora)
        {
            string query = string.Format("INSERT INTO bitacora (id_usuario,descripcion,criticidad,fecha,dvh) VALUES ({0},'{1}',{2},'{3}',{4})",
                bitacora.usuario.id, bitacora.descripcion, bitacora.criticidad, bitacora.fecha.ToString("yyyy-MM-dd HH:mm"), bitacora.dvh);

            _acceso.ExecuteNonQuery(query);
        }

    }
}
